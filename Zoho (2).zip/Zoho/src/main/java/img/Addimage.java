package img;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import jakarta.servlet.annotation.MultipartConfig;
import jakarta.servlet.http.Part;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.sql.*;
import javax.sql.*;
/**
 * Servlet implementation class Addimage
 */
@MultipartConfig
@WebServlet("/AddImage")
public class Addimage extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public Addimage() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//doGet(request, response);
	
		//System.out.println("In do post method of Add Image servlet.");
		String uname=request.getParameter("uname");
		String phone=request.getParameter("phone");
		String SlowNet=request.getParameter("SlowNet");
		String WeakWifi=request.getParameter("WeakWifi");
		String PhyCon=request.getParameter("PhyCon");
		String NoNet=request.getParameter("NoNet");
		String WifiCon=request.getParameter("WifiCon");
		String WifiDrop=request.getParameter("WifiDrop");
		String DNSRes=request.getParameter("DNSRes");
		Part file=request.getPart("myimg");
	
		String imageFileName = file.getSubmittedFileName();
		//System.out.println("Selected File " + imageFileName); //get Selected Image File Name
	
		
		String uploadPath="C:/Users/Admin/eclipse-workspace/Zoho/src/main/webapp/images/"+imageFileName;
		//String uploadPath="C:/Users/Admin/eclipse-workspace/Image/src/main/webapp/images/"+imageFileName;
		//String uploadPath="C:/Users/Admin/eclipse-workspace/Image/images/"+imageFileName;
		//System.out.println("upload Path : "+uploadPath);
		try {
			FileOutputStream fos = new FileOutputStream(uploadPath);
	
			InputStream is = file.getInputStream();
	
			byte[] data=new byte[is.available()];
			is.read(data);
			fos.write(data);
			fos.close();
		}
		catch(Exception e){
			e.printStackTrace();
		}
		
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/airrelservices","root","Anchana21");
			PreparedStatement stmt;
			String query="insert into technicalgrievance(Name,Phone,SlowNet,WeakWifi,PhyCon,NoNet,WifiCon,WifiDrop,DNSRes,image) values(?,?,?,?,?,?,?,?,?,?)";
			stmt=con.prepareStatement(query);
			stmt.setString(1,uname);
			stmt.setString(2,phone);
			stmt.setString(3,SlowNet);
			stmt.setString(4,WeakWifi);
			stmt.setString(5,PhyCon);
			stmt.setString(6,NoNet);
			stmt.setString(7,WifiCon);
			stmt.setString(8,WifiDrop);
			stmt.setString(9,DNSRes);
			stmt.setString(10,imageFileName);
			int row = stmt.executeUpdate();
			if(row>0) {
				response.sendRedirect("technicalsucc.jsp"); 
			}
			else {
				System.out.println("Error Occured");
			}
			 
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}

